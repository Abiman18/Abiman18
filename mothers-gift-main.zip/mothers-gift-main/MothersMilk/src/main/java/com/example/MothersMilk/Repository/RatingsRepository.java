package com.example.MothersMilk.Repository;

import com.example.MothersMilk.Model.Ratings;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RatingsRepository extends JpaRepository<Ratings ,Integer> {
}
