package com.example.MothersMilk.Services;

import com.example.MothersMilk.Model.Donation;
import com.example.MothersMilk.Model.UserLogIn;
import com.example.MothersMilk.Repository.DonationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service

public class DonationServiceImpl implements DonationService{
    @Autowired
    DonationRepository donationRepository;
    @Autowired
    UserLogInService userLogInService;
    public DonationServiceImpl(DonationRepository donationRepository){
        this.donationRepository=donationRepository;
    }
    @Override
    public List<Donation> getDonation() {
        List<Donation> donations = new ArrayList<>();
        donationRepository.findAll().forEach(donations::add);
        return donations;
    }

    @Override
    public Donation insertDonation(Donation donation) {
        return donationRepository.save(donation);
    }

    @Override
    public List<UserLogIn> getRecipientsByDonorId(Integer donorId) {
        UserLogIn donor = userLogInService.getLoginById(donorId);
        List<Donation> donationsByDonor = donationRepository.findByDonor(donor);

        List<UserLogIn> recipients = new ArrayList<>();
        for (Donation donation : donationsByDonor) {
            recipients.add(donation.getRecipient());
        }

        return recipients;
    }
}

