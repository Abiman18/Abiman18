import React, { useState } from 'react';
import './recepientform.css';
import logo from './logo.png';



function RecepientForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    contactNumber: '',
    age: '',
    address: '',
    medicalPrescription: null,
  });

  const [uploadedPrescription, setUploadedPrescription] = useState(null);

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === 'medicalPrescription') {
      setFormData({
        ...formData,
        [name]: files[0],
      });
      setUploadedPrescription(files[0] ? files[0].name : null);
    } else {
      setFormData({
        ...formData,
        [name]: value,
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // You can add your form submission logic here
    console.log(formData);
  };

  return (
    <div>
      
    <div>
      <div className="signup-form">
       <h1>Recepient Sign up</h1>
       
        <form onSubmit={handleSubmit}>
          <div className="lcolumn">
            <label htmlFor="name">Name</label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
            />
            <label htmlFor="babyname">Baby Name</label>
            <input
              type="text"
              id="babyname"
              name="babyname"
              value={formData.babyname}
              onChange={handleChange}
              required
            />
            <label htmlFor="email">Email ID</label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
            />
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              required
            />
          </div>
          <div className="rcolumn">
            <label htmlFor="contactNumber">Contact Number</label>
            <input
              type="tel"
              id="contactNumber"
              name="contactNumber"
              value={formData.contactNumber}
              onChange={handleChange}
              required
            />
            
            <label htmlFor="address">Address</label>
            <input
              type="text"
              id="address"
              name="address"
              value={formData.address}
              onChange={handleChange}
              required
            />
            <label htmlFor="medicalPrescription">Medical Prescription</label>
            <input
              type="file"
              id="medicalPrescription"
              name="medicalPrescription"
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={handleChange}
            />
            {uploadedPrescription && (
              <div className="uploaded-prescription">
                Uploaded Prescription: {uploadedPrescription}
              </div>
            )}
          </div>
          <button type="submit" className="submit-button">
            Submit
          </button>
        </form>
      </div>
    </div>
  </div>

  );
}

export default RecepientForm;

