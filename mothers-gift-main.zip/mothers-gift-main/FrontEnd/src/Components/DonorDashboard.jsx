import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './DonorDashboard.css';
import userLogo from './profile logo.jpg';
import avatar from './profilecircle.png';
function DonorDashboard({ userId }) {
  const [recipients, setRecipients] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get(`http://localhost:8085/api/v1/donations/recipients/${userId}`)
      .then((response) => {
        setRecipients(response.data);
      })
      .catch((error) => {
        setError('Error fetching recipients: ' + error.message);
      });
  }, [userId]);

  const toggleDetails = (index) => {
    const updatedRecipients = [...recipients];
    updatedRecipients[index].showDetails = !updatedRecipients[index].showDetails;
    setRecipients(updatedRecipients);
  };

  return (
    <div className = "recipientlist">
      <div className="nav-bar">
                <div className="nav-logo">
                    <h1>MOTHER'S GIFT</h1>
                </div>
                <div className="nav-links">
                    <a href="/">Home</a>
                    <a href="/">About Us</a>
                    <a href="/">Help</a>
                </div>
                <div className="loggedin-user">
                    <img src={avatar} alt="user-profile" height={50} width={50} />
                    <p>Donor UserName</p>
                </div>
            </div>
    <div className="app-container">
      {recipients.map((recipient, index) => (
        <div className="profile-section" key={recipient.userId}>
          <img src={userLogo} alt="Profile" className="profile-image" width={100} />
          <div className="profile-info">
            <h2 style={{ fontSize: '2rem', marginTop: 0 }}>REQUESTED RECIPIENT</h2>
            <div className="detail">
              <label>Name:</label>
              <span>{recipient.name}</span>
            </div>
            <div className="user-profile-details">
              <button
                className="view-profile-button"
                onClick={() => toggleDetails(index)}
              >
                {recipient.showDetails ? 'Hide Details' : 'View Details'}
              </button>
            </div>
            {recipient.showDetails && (
              // Additional details to display when "View Details" is clicked
              <div>
                <div className="detail">
                  <label>Aadhaar ID:</label>
                  <span>{recipient.aadhaarId}</span>
                </div>
                <div className="detail">
                  <label>Email ID:</label>
                  <span>{recipient.emailId}</span>
                </div>
                <div className="detail">
                  <label>Contact:</label>
                  <span>{recipient.contact}</span>
                </div>
                <div className="detail">
                  <label>Address:</label>
                  <span>{recipient.address}</span>
                </div>
                <div className="detail">
                  <label>Doctor Prescription:</label>
                  <span>{recipient.medicalReport}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      ))}
      {error && <p>{error}</p>}
    </div>
    </div>
  );
}

export default DonorDashboard;
