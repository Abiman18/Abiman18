import "./Signup.css";
import logo from './logo.png';
import React, { useState } from 'react';
import RecepientForm from "./RecepientForm";
import DonorForm from "./DonorForm";
import Navbar from "./Navbar";



function Signup() {

  const [selectedOption, setSelectedOption] = useState('Recepient'); 
  const handleOptionChange = (event) => {
    setSelectedOption(event.target.value);
    console.log(selectedOption);
  };
  return (
   <div className="App">
     <Navbar/>
    <div className="signup-page">
      {/* <img src={logo} alt="Logo" className="logo" />
    <div>
      <span className="top-left-word">Safe.Trusted.lifesaving</span>  
    </div> */}
      <select value={selectedOption} onChange={handleOptionChange} className="selectRoleButton">
        <option value="Recepient">Recepient</option>
        <option value="donor">Donor</option>
      </select>
      {selectedOption === 'Recepient' ? <RecepientForm /> : <DonorForm />}

  </div>
     
    </div>
  );
}

export default Signup;
