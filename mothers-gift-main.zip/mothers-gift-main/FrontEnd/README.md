# Mother's Gift Frontend (React)

Welcome to the frontend of Mother's Gift, a groundbreaking online platform dedicated to bridging the gap between milk donors and infants in need. This React application is a critical part of the project's user interface.

## Getting Started

These instructions will help you get a copy of the frontend up and running on your local machine for development and testing purposes.

### Prerequisites

Before you begin, ensure you have met the following requirements:

- Node.js: Make sure you have Node.js installed. You can download it from [nodejs.org](https://nodejs.org/).

### Installing Dependencies

1. Clone the repository to your local machine:

   ```bash
   https://github.com/suidbit/mothers-gift.git
   cd mothers-gift-frontend
2.Install the project dependencies using npm (Node Package Manager):
   npm install

   
3.Running the Application (Frontend)
   Start the React development server:
   npm start


The application should now be running locally at http://localhost:3000 in your web browser.
   
