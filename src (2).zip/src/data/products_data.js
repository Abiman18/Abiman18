
const product_card=[
    
    {
        id: 1,
        product_name:"Cycle",
        description:"Better and No damage",
        Contact:"Contact",
        thumb:"./images/1.png"

    },
    {
        id: 2,
        product_name:"Books",
        description:"Better and No damage",
        Contact:"Contact",
        thumb:"./images/2.jpg"   
    },
    {
        id: 3,
        product_name:"Sweater",
        description:"Better and No damage",
        Contact:"Contact",
        thumb:"./images/3.jpg"
    },
    {
        id: 4,
        product_name:"Sportskits",
        description:"Good condition",
        Contact:"Contact",
        thumb:"./images/4.png"
    },
    {
        id: 5,
        product_name:"Shirts",
        description:"Better",
        Contact:"Contact",
        thumb:"./images/5.png"
    }

    
]

export default product_card;
