import React, {useState, useEffect} from 'react'
import './header.css';

export default function Header() {
  const [toggleMenu, setToggleMenu] = useState(false)
  const [screenWidth, setScreenWidth] = useState(window.innerWidth)




  const toggleNav = () => {
    setToggleMenu(!toggleMenu)
  }


  useEffect(() => {

    const changeWidth = () => {
      setScreenWidth(window.innerWidth);
    }

    window.addEventListener('resize', changeWidth)

    return () => {
      window.removeEventListener('resize', changeWidth)
  }


  }, [])

  return (
    <nav>
        <div className='logo'>Needed</div>
        {(toggleMenu || screenWidth > 500) && (
        <ul className='list'>
            <li className='items'>Home</li>
            <li className='items'>Type here to search</li>
            <li className='items'>Add products</li>
            <li className='items'>Profile</li>
        </ul>
        )}
        <button onClick={toggleNav} className="btn">MENU</button>

    </nav>
  )
}
