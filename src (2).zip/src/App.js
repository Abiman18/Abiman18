import React from 'react';
import './App.css';
import Header from './Components/Nav.js/header';
import MainContent from './Components/MainContent';


function App() {
  return (

    <div className="Container">
      <Header/>
      <MainContent/>


    </div>

  );
}

export default App;
